#include "../headers/elem_pilha.h"

ElemPilha::ElemPilha(string token, int estado)
{
    this->token = token;
    this->estado = estado;
}